DROP TABLE Police_Stations;
COMMIT;