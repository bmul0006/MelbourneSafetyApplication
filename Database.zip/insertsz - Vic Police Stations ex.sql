﻿INSERT INTO melbourne_safety.crime_stats(Station_Name,STATION_NUMBER,LATITUDE,LONGITUDE) VALUES ('Clayton',1,37,145);
