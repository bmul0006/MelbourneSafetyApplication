package com.example.gps;

import android.annotation.SuppressLint;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;

import com.android.volley.AuthFailureError;
import com.android.volley.NetworkError;
import com.android.volley.ParseError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.ServerError;
import com.android.volley.TimeoutError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MapStyleOptions;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.libraries.places.api.Places;
import com.google.android.libraries.places.api.model.Place;
import com.google.android.libraries.places.api.model.RectangularBounds;
import com.google.android.libraries.places.api.model.TypeFilter;
import com.google.android.libraries.places.widget.AutocompleteSupportFragment;
import com.google.android.libraries.places.widget.listener.PlaceSelectionListener;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.maps.android.data.geojson.GeoJsonFeature;
import com.google.maps.android.data.geojson.GeoJsonLayer;
import com.google.maps.android.data.geojson.GeoJsonPolygonStyle;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


public class MainActivity extends AppCompatActivity implements OnMapReadyCallback {

    TextView lgaInfo;

    // Variables
    private static final String TAG = MainActivity.class.getSimpleName();
    private String userID;
    private String trackLink;
    public final String APIKEY = BuildConfig.APIKEY;

    private GoogleMap mMap;
    GeoJsonLayer layer;
    String currentLGA;
    boolean choroplethOn;
    boolean policeOn;

    // A default location (Melbourne, Australia)
    private final LatLng defaultLocation = new LatLng(-37.8136, 144.9631);

    // Colors for Choropleth map
    public int lowestColor = Color.argb(125, 201, 111, 47);
    public int lowColor = Color.argb(125, 231, 176, 86);
    public int midColor = Color.argb(125, 255, 242, 143);
    public int highColor = Color.argb(125, 159, 197, 73);
    public int highestColor = Color.argb(125, 8, 152, 20);
    public int clearColor = Color.argb(0, 0, 0, 0);

    // Polygon Styles
    GeoJsonPolygonStyle highestStyle = new GeoJsonPolygonStyle();
    GeoJsonPolygonStyle highStyle = new GeoJsonPolygonStyle();
    GeoJsonPolygonStyle midStyle = new GeoJsonPolygonStyle();
    GeoJsonPolygonStyle lowStyle = new GeoJsonPolygonStyle();
    GeoJsonPolygonStyle lowestStyle = new GeoJsonPolygonStyle();
    GeoJsonPolygonStyle clearStyle = new GeoJsonPolygonStyle();

    // URL for police dataset
    public final String serverURL = "http://13.236.36.223/";
    public final String policeURL = serverURL + "police_lat_long";
    public final String ratingsURL = serverURL + "lga_ratings";
    public JSONArray lgaRatings;
    public JSONArray policeLatLng;
    List<Marker> mMarkers = new ArrayList<>();


    @SuppressLint("HardwareIds")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Unique ID for device
        userID = Settings.Secure.getString(this.getContentResolver(),
        Settings.Secure.ANDROID_ID);

        setContentView(R.layout.activity_main);

        FloatingActionButton fab = findViewById(R.id.fab);
        FloatingActionButton fabDash = findViewById(R.id.fab2);
        ImageButton zoomInBtn = findViewById(R.id.zoomInBtn);
        ImageButton zoomOutBtn = findViewById(R.id.zoomOutBtn);
        lgaInfo = findViewById(R.id.currentLGA);

        highestStyle.setFillColor(highestColor);
        highestStyle.setStrokeWidth(3F);
        highestStyle.setStrokeColor(Color.BLACK);

        highStyle.setFillColor(highColor);
        highStyle.setStrokeWidth(3F);
        highStyle.setStrokeColor(Color.BLACK);

        midStyle.setFillColor(midColor);
        midStyle.setStrokeWidth(3F);
        midStyle.setStrokeColor(Color.BLACK);

        lowStyle.setFillColor(lowColor);
        lowStyle.setStrokeWidth(3F);
        lowStyle.setStrokeColor(Color.BLACK);

        lowestStyle.setFillColor(lowestColor);
        lowestStyle.setStrokeWidth(3F);
        lowestStyle.setStrokeColor(Color.BLACK);

        clearStyle.setFillColor(clearColor);
        clearStyle.setStrokeWidth(3F);
        clearStyle.setStrokeColor(Color.BLACK);

        // Functionality for get location button
        fab.setOnClickListener(view -> {
            //getLocation();
        });

        // GoogleMap Fragment
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.maps);
        assert mapFragment != null;
        mapFragment.getMapAsync(this);

        // Autocomplete search
        Places.initialize(getApplicationContext(), APIKEY);

        // Initialize the AutocompleteSupportFragment
        AutocompleteSupportFragment autocompleteFragment = (AutocompleteSupportFragment)
                getSupportFragmentManager().findFragmentById(R.id.autocomplete_fragment);

        assert autocompleteFragment != null;
        autocompleteFragment.setTypeFilter(TypeFilter.ADDRESS);
        autocompleteFragment.setLocationBias(RectangularBounds.newInstance(
                new LatLng(-38.388695, 144.015627),
                new LatLng(-37.366701, 145.783542)));
        autocompleteFragment.setCountries("AU");

        // Specify the types of place data to return.
        autocompleteFragment.setPlaceFields(Arrays.asList(Place.Field.ID, Place.Field.NAME, Place.Field.LAT_LNG));
        autocompleteFragment.setOnPlaceSelectedListener(new PlaceSelectionListener() {
            @Override
            public void onPlaceSelected(@NonNull Place place) {
                LatLng latLng = place.getLatLng();
                changeLocation(latLng);
            }

            @Override
            public void onError(@NonNull Status status) {
                Toast.makeText(MainActivity.this, "No address matches", Toast.LENGTH_SHORT).show();
            }
        });

        // Zoom buttons functionality
        zoomInBtn.setOnClickListener(view -> mMap.animateCamera(CameraUpdateFactory.zoomIn()));
        zoomOutBtn.setOnClickListener(view -> mMap.animateCamera(CameraUpdateFactory.zoomOut()));

        // Sending current LGA to web view
        fabDash.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this, Dashboard.class);
            intent.putExtra("lga_name", currentLGA);
            intent.putExtra("url", serverURL);
            startActivity(intent);
        });

        // Toolbar
        Toolbar toolbar = findViewById(R.id.my_toolbar);
        toolbar.setTitle("Melbourne Safety");
        setSupportActionBar(toolbar);

        // Coordinate tracking
        final int delay = 2000; //run every 2 seconds
        new Handler(Looper.getMainLooper()).postDelayed(this::sendLatLong, delay);
    }


    /**
     * Inflates menu in the toolbar
     * @param menu: Toolbar menu
     * @return boolean: Returns true when menu toolbar is inflated
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.options, menu);
        return true;
    }


    /**
     * Handles functionality of the toolbar buttons when pressed
     * @param item: Menu button from the toolbar
     * @return boolean: Returns true if button was pressed
     */
    @SuppressLint("NonConstantResourceId")
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            // Set Location Button
            case R.id.action_favorite:
                setPoliceStations(mMarkers);
                return true;

            case R.id.toggleChoro:
                toggleChoropleth();
                return true;

            case R.id.copy_link:
                copyLinkToClipboard();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    /**
     * Loads GoogleMaps and adds LGA polygon shape
     * @param googleMap: GoogleMap instance
     */
    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        mMap = googleMap;
        googleMap.setMapStyle(MapStyleOptions.loadRawResourceStyle(this, R.raw.map_styles));

        // Adding the Choropleth Map layer
        try {
            layer = new GeoJsonLayer(mMap, R.raw.lga, this);

            // Getting JSON object from server
            getJSON(() -> colorMap(layer), ratingsURL);

            GeoJsonPolygonStyle polygonStyle = layer.getDefaultPolygonStyle();
            polygonStyle.setFillColor(clearColor);
            polygonStyle.setStrokeWidth(3F);
            polygonStyle.setStrokeColor(Color.BLACK);
            layer.addLayerToMap();
            choroplethOn = true;

            // Displays LGA name when clicked
            layer.setOnFeatureClickListener((GeoJsonLayer.GeoJsonOnFeatureClickListener) feature -> {
                currentLGA = feature.getProperty("NAME");
                String info = "LGA: " + currentLGA;
                lgaInfo.setText(info);

            });
        }
        catch (IOException e){
            Log.e(TAG, "cannot be read");
            e.printStackTrace();
        }
        catch (JSONException e){
            Log.e(TAG, "cannot be converted to JSON object");
            e.printStackTrace();
        }

        policeOn = false;
        // Get police coordinates and add markers
        getJSON(() -> setPoliceStations(mMarkers), policeURL);

        // Move the center of the camera to Melbourne CBD
        mMap.moveCamera(CameraUpdateFactory.newLatLng(defaultLocation));
        mMap.animateCamera(CameraUpdateFactory.zoomTo(12));
    }


    /** Sends the current latitude and longitude to the server */
    private void sendLatLong() {
        RequestQueue queue = Volley.newRequestQueue(this);
        double currentLat = -37.9145;
        double currentLong = 145.1350;
        String url = serverURL + "get_location?userID=" + userID + "&lat=" + currentLat +
                "&long=" + currentLong;
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                response -> trackLink = response, null);

        queue.add(stringRequest);
    }


    /** Copies the tracker link to the device's clipboard */
    private void copyLinkToClipboard() {
        ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        ClipData clip = ClipData.newPlainText("Link", trackLink);
        clipboard.setPrimaryClip(clip);
        Toast.makeText(this, clipboard.getPrimaryClip().toString(), Toast.LENGTH_LONG).show();
    }


    /**
     * Changes map location to the given latitude and longitude
     * @param latLng: latitude and longitude object
     */
    public void changeLocation(LatLng latLng){
        CameraPosition cameraPosition = new CameraPosition.Builder()
                .target(latLng)
                .zoom(18)
                .build();
        mMap.moveCamera(CameraUpdateFactory.newCameraPosition(cameraPosition));
    }


    /** Interface to call functions when background process is completed */
    public interface VolleyCallBack {
        void onSuccess();
    }

    /**
     * Retrieves LGA ratings (JSON array) from the server
     * @param callBack: Volley callback
     */
    public void getJSON(final VolleyCallBack callBack, String url){
        // Volley
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null, response -> {
            try {
                if(url.equals(ratingsURL)){
                    lgaRatings = response.getJSONArray("LGA");
                }
                else if(url.equals(policeURL)){
                    policeLatLng = response.getJSONArray("police_stations");
                }
                callBack.onSuccess();
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }, error -> {
            String message = null;
            if (error instanceof NetworkError) {
                message = "Cannot connect to Internet...Please check your connection!";
            } else if (error instanceof ServerError) {
                message = "The server could not be found. Please try again after some time!!";
            } else if (error instanceof AuthFailureError) {
                message = "Cannot connect to Internet...Please check your connection!";
            } else if (error instanceof ParseError) {
                message = "Parsing error! Please try again after some time!!";
            } else if (error instanceof TimeoutError) {
                message = "Connection TimeOut! Please check your internet connection.";
            }
            Toast.makeText(MainActivity.this, message, Toast.LENGTH_SHORT).show();
        });
        requestQueue.add(jsonObjectRequest);
    }

    /**
     * Fills each LGA polygon with their respective colours
     * @param layer: GeoJson layer that contains LGA polygons
     * @return boolean: true if it successfully looped through the data
     */
    // Colors each polygon(LGA) with the ratings from the JSON array
    public boolean colorMap(GeoJsonLayer layer){

        if(lgaRatings != null){
            for (int p = 0; p < lgaRatings.length(); p++) {
                try {
                    JSONObject data = lgaRatings.getJSONObject(p);
                    String lga_name = data.getString("name");
                    lga_name = lga_name.toLowerCase();
                    int lga_score = data.getInt("rating");

                    // For each LGA polygon:
                    for (GeoJsonFeature f : layer.getFeatures()) {
                        String lga_string = f.getProperty("NAME");
                        lga_string = lga_string.toLowerCase();

                        if (lga_string.equals(lga_name)){
                            if (lga_score == 1)
                                f.setPolygonStyle(lowestStyle);
                            else if (lga_score == 2){
                                f.setPolygonStyle(lowStyle);
                            }
                            else if (lga_score == 3){
                                f.setPolygonStyle(midStyle);
                            }
                            else if (lga_score == 4){
                                f.setPolygonStyle(highStyle);
                            }
                            else if (lga_score == 5){
                                f.setPolygonStyle(highestStyle);
                            }
                        }
                    }
                }
                catch (JSONException e) {
                    e.printStackTrace();
                }
            }
            return true;
        }
        else{
            Toast.makeText(getApplicationContext(),
                    "Choropleth map is not available at this time.",
                    Toast.LENGTH_SHORT).show();
            return false;
        }
    }

    /** Toggles the choropleth map on/off */
    public void toggleChoropleth(){
        if(choroplethOn){
            clearMap();
            choroplethOn = false;
        }
        else {
            choroplethOn = colorMap(layer);
        }
    }

    /** Remove the colours from the choropleth map */
    public void clearMap(){
        for (GeoJsonFeature f : layer.getFeatures()) {
            f.setPolygonStyle(clearStyle);
        }
    }


    /** Add police markers to the map */
    public void setPoliceStations(List<Marker> markers){
        if (markers.isEmpty()){
            BitmapDescriptor police_marker = bitmapDescriptorFromVector(this, R.drawable.ic_police_marker);
            if(policeLatLng != null){
                for (int p = 0; p < policeLatLng.length(); p++) {
                    try {
                        JSONObject data = policeLatLng.getJSONObject(p);
                        double latitude = data.getDouble("lat");
                        double longitude = data.getDouble("long");
                        String suburb = data.getString("name");
                        LatLng station = new LatLng(latitude, longitude);

                        MarkerOptions markerOptions = new MarkerOptions();
                        markerOptions.position(station);
                        Marker marker = mMap.addMarker(markerOptions);
                        assert marker != null;
                        marker.setTitle("Police station in " + suburb);
                        marker.setIcon(police_marker);
                        markers.add(marker);

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
                policeOn = true;
            }
            else{
                Toast.makeText(getApplicationContext(),
                        "Police station markers are not available at this time.",
                        Toast.LENGTH_SHORT).show();
            }
        }
        else if(policeOn){
            for (Marker marker: markers) {
                marker.setVisible(false);
            }
            policeOn = false;
        }
        else {
            for (Marker marker: markers) {
                marker.setVisible(true);
            }
            policeOn = true;
        }
    }

    /**
     * Converts vector asset (image) to BitmapDescriptor
     * @param context: Context of the application
     * @param vectorResId: ID for the vector asset
     * @return result: BitMapDescriptor of image
     */
    private BitmapDescriptor bitmapDescriptorFromVector(Context context, int vectorResId) {
        Drawable vectorDrawable = ContextCompat.getDrawable(context, vectorResId);
        assert vectorDrawable != null;
        vectorDrawable.setBounds(0, 0, vectorDrawable.getIntrinsicWidth(), vectorDrawable.getIntrinsicHeight());
        Bitmap bitmap = Bitmap.createBitmap(vectorDrawable.getIntrinsicWidth(), vectorDrawable.getIntrinsicHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        vectorDrawable.draw(canvas);
        return BitmapDescriptorFactory.fromBitmap(bitmap);
    }
}